---
author: "Alexis Tacnet"
date: 2015-09-28
title: Example article
best: true
---

## Text

**This is some text.** Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pretium at ipsum eu pharetra. Proin ac ante et leo ultrices bibendum. Vivamus id ipsum fermentum, aliquam nunc mollis, tempus sapien. Praesent scelerisque cursus eros vitae pretium. Etiam sit amet ligula in leo euismod malesuada. Proin eleifend pulvinar ipsum, eu lobortis ante pharetra eu. Vivamus sem elit, venenatis eget ornare nec, ullamcorper non tellus. Duis quis massa finibus, euismod erat quis, fermentum nunc. Maecenas euismod felis sit amet convallis placerat.

## Images

**This theme includes a tranparent way to defer images. This can be enabled/disabled in the `config.toml`.**

![image](/img/startup.jpg)

**You will just have to do two images : the normal, and a low resolution one.**

## Code

**This is some code, this theme includes language highlight, optionnal as well.**

```
.dark {
  color: #333333 !important;
}
.light {
  color: #666666 !important;
}
.accent {
  color: #428bca !important;
}
```