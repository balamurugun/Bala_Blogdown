+++
title = "Home"
+++

_This is the home page. It will display the blog section if there is one, and a text before._

Hey ! Welcome to the **Cocoa Enhanced theme**. Here are some articles :