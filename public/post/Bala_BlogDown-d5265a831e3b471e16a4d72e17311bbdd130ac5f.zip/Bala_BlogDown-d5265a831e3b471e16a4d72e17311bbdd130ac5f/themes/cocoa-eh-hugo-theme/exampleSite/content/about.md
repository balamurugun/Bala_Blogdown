+++
date = "2015-08-22"
title = "About"
+++

_With this theme, it is possible to add small sections that only contains one page like this. It will automatically appears in the header, at the end._

Along with [Ford Prefect](https://en.wikipedia.org/wiki/Ford_Prefect_\(character\)), Dent barely escapes the Earth's destruction as it is demolished to make way for a *hyperspace bypass*. Arthur spends the next several years, still wearing his dressing gown, helplessly launched from crisis to crisis while trying to straighten out his lifestyle.  
 
> He rather enjoys tea, but seems to have trouble obtaining it in the far reaches of the galaxy.  
 
In time, he learns how to fly and carves a niche for himself as a sandwich-maker.