---
title: Sunday Latte - 26 April 2020
author: Balamurugan
date: '2020-04-25'
slug: weekly-reading-25-april-2020
categories: []
tags: []
description: Desc
hacker_news_id: ''
lobsters_id: ''
meta_img: /images/image.jpg
---
Here are few good articles from last week readings

# [Career advice for people with bad luck](https://chiefofstuff.substack.com/p/career-advice-for-people-with-bad)


+ Politics emerge when the players believe the game is zero sum. 
+ Try not to learn the wrong habits.
+ [Failure I call living](https://www.youtube.com/watch?v=dlvZtXTEMug)

Give a full read, worth it

# [How to overcome mental laziness](https://news.ycombinator.com/item?id=22919697) <br />


If you have already reached reading till this, you don't need them :)
Few gems from the conversation:

+ Stop being so goal focused and instead become habit focused. You don't want to accomplish some big goal, all you want to do is do fun stuff that makes you a better person. As a result of that, you'll probably accomplish some cool goals.

+ Some helpful tools are reminders, taking notes, reviewing prior decisions, and advice from other people

+ Break the problems down into smaller tasks until the first task is too small to offer resistance.Almost everything in my to do list these days can be executed in under 10 minutes. 

+ 3sec rule: If you want to do something, don't give yourself time to come up with an excuse not to, because you will convince yourself.


# Others

[Goldman Sachs Lists Buy And Sell Stock Ideas Amid Market Downcycle](https://www.bloombergquint.com/markets/goldman-sachs-lists-buy-and-sell-stock-ideas-amid-market-downcycle)

### Aha....{{< tweet 1254069494680621056 >}} 

### The End
