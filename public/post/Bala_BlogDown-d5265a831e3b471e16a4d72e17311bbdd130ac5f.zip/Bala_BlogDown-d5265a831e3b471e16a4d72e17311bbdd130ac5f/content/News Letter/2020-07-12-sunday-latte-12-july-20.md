---
title: Sunday Latte-12 July 20
author: Balamurugan
date: '2020-07-11'
slug: sunday-latte-12-july-20
categories: []
tags: []
description: My Toastmaster speech
hacker_news_id: ''
lobsters_id: ''
meta_img: /images/image.jpg
---

Below is the transcript of my recent Toastmaster speech. Let me know if you disagree!

In the early 1980s, a black student writes a letter ,_“Mom, I am left with only $20 of cash. Please deposit some cash in my account and send some stamps or free food coupons”_. How do you think his life would have panned out now? Cut to 2020, he is the worth $2 billion and his records are untouched since he retired from basketball 20 years back.

Michael Jordan played in the US NBA League for the team Chicago Bulls.

He won the MVP five times in his career. Around the 1990s, the world agreed Micheal is the best talent in the basketball. But he had no team championship to his name. His coach would chide him to pass the ball often to his teammates rather than taking shots himself and reminded there is no I in the team. Micheal response would be there is an I in the win. But over the period his leadership style has changed as the captain of the team an won team Chicago Bulls win championship six times.
It is Sachin and Dhoni in a single body,

Let us sample a few people and incidents around Michael to learn about him.

### Scottie Pippen

Scottie is the #2 player in Chicago bulls after Michael. Michael goes on break from basketball and Scottie takes the lead.

Michale is out that season and Scottie is leading the season for Chicago Bulls. In one of the games, Coach throws the ball not to the captain Scottie but to another guy for a crucial shot. Scottie opts to sit out and he refuses to enter the game. This left everyone in deep shock for being not a good sport literally.

There is no Michael if there was no Scottie by Michael's own admission.Even though Scottie is his best guy, Michael Jordan provides candid feedback to Scottie that you want to live with your own decision and you should not have done that. Somebody who is politically correct and needs a lot of favor from Scottie int the future would have supported Scotties action or would have said no comments. In spite Michael criticized and their relationship grew.

When someones say “I don't agree”, I don't need to see them as rude. Also putting out disagreement tactfully is like a vaccine, which doesn't kill but helps you thrive.

### Dennis Roadman

In 1997,Scottie is out due to injury. Dennis was assigned to play the #2 role and he was made accountable. In one game, he picked up a fight with opponent, got kicked out by refree and left Michael hanging in there. That night, Scottie walks in Micheals room.He apologies to Michael in a unique way by asking him for a cigar and leaves saying without saying my bad. After that, he becomes straight as an arrow. And he goes on to play a formidable #2 for the rest of season.

Not only that, Roadman is a controversial figure in NBA playing for a different team before picked by Chicago bulls. Everyone had a visceral reaction and imagined him to fail. Jordan supported him saying he can help us win because he is tough.

The first instinct when we work with someone who doesn't look like us or doesn't think like us is to see them as a threat or dismiss them as minon. But as long as their purpose is aligned with greater good we should hold, ignite and celebrate them. As Aln Turing said,"Sometimes it is the people no one can imagine anything of who do the things no one can imagine”

### Steve Kerr
So there is a practice game, where Steve and MJ are competing vigorously. Match was so intense, a tiff escalates, Steve punches Micheal and Michael knocks him back. As turn of events, after this episode, Michaels respect for steve goes up and Michael by his own admission starts trusting his teammates. So much that he threw the ball to steve for a final shot in a final instead of his usual self trying. Steve obliges with a perfect shot eventually sealing the game. Don't try this at office. As they say, if somebody expects a superior performance, you might eventually end up delivering one.  

Remember, Steve calls himself as an overachiever and need to claw his way up as he felt he was not naturally gifted.Micheal helped Steve to see his own worth.

Here are the three things I learned: its ok to disagree, embrace your opposites and expect higher performance, you might mostly end up getting it.

Also another point to note is Michael Jordan owes a lot of success to his Coach Phil Jackson and so do my speech to Netflix documentary “The Last Dance”.

The End.