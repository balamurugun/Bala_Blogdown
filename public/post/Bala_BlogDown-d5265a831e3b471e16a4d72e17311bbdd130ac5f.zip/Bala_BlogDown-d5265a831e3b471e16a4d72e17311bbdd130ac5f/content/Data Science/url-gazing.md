---
title: URL Gazing
author: Balamurugan
date: '2020-05-09'
slug: url-gazing
categories: []
tags: []
description: Desc
hacker_news_id: ''
lobsters_id: ''
meta_img: /images/image.jpg
---

#Mental model
The Map Is Not the Territory/Menu is not the Meal
[https://fs.blog/2015/11/map-and-territory/]