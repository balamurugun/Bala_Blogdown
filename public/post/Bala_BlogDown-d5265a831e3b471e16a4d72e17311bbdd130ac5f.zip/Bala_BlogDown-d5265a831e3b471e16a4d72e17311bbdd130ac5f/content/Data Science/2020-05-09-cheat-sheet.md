---
title: Cheat Sheet
author: Balamurugan
date: '2020-05-09'
slug: cheat-sheet
categories: []
tags: []
description: Desc
hacker_news_id: ''
lobsters_id: ''
meta_img: /images/image.jpg
---

# Database
+ Ask HN: What are some examples of good database schema designs?[https://news.ycombinator.com/item?id=22324691]


